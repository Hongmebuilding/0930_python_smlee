class House:
    """
그냥 만들어본 것(아무 의미 없음)
    """
    house_count = 0

    def __init__(self, name):
        print("새로운 집이 생성되었습니다.")
        self.name = name
        House.house_count += 1

    def __init__(self):
        print("새로운 집이 생성되었습니다.")
        self.name = "이름없어"

class Apart:
    def __init__(self):
        print('새로운 "아파트"가 만들어졌습니다')

        self.room = 3
        self.furniture = []

    def setRoom(self, i):
        self.room = i

    def getRoom(self):
        return self.room

    def addFurniture(self, str):
        self.furniture.append(str)

    def getFurniture(self):
        return self.furniture


