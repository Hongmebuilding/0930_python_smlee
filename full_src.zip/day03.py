"""
    Day3 Crawling
    Version : 1.0
    Created : 2021.12.14
    Updated : 2021.12.14
    Author  : J.W.Lee
"""
import requests
from bs4 import BeautifulSoup

url = 'https://movie.naver.com/movie/bi/mi/basic.naver?code=191559#'
response = requests.get(url)
print("웹서버의 응답은", response.status_code)
print("웹서버의 응답시간은", response.elapsed)
#print(response.text)

# 한글 깨질 때의 처리
url = 'http://www.samsungfire.com'
response = requests.get(url)
print(response.encoding)
response.encoding = None
#print(response.text)

url = 'https://movie.naver.com/movie/bi/mi/basic.naver?code=191559#'
response = requests.get(url)
html = response.text
soup = BeautifulSoup(html, 'html.parser')

res = soup.find('div')
res2 = soup.find('div').text
res3 = soup.find('div').get('id')
print(res)
print(res2)
print(res3)

list = soup.find_all('div', class_='tx_top')
print(list)

for idx, str in enumerate(list):
    print(idx+1, str.find('strong').text)

list2 = soup.find('p', class_='con_tx')
print(list2.text)

list3 = soup.find_all('h5')
print('****** 한 줄 이야기 요약 ******')
print(list3[0].text)

#url = 'https://finance.naver.com/item/frgn.naver'
url = 'https://finance.naver.com/item/frgn.naver?code=005930&page=2'
param = {'code':'005930', 'page':'1'}
#response = requests.get(url, params=param)
response = requests.get(url)
print(response.text)