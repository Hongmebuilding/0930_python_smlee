"""
    Day6 Numpy
    Version : 1.0
    Created : 2021.12.17
    Updated : 2021.12.17
    Author  : J.W.Lee
"""
import numpy as np
import myutils as mu

# 1. 행렬의 생성 1
mu.cprintTitle('1) 1차원 행렬')
array = np.array([1, 2, 3])
array2 = np.array(range(5))
print(array)
print(array2)

mu.cprintTitle('2) 2차원 행렬')
array = np.array([[1,2,3],[4,5,6]])
print(array)

mu.cprintTitle('3) 3차원 행렬')
array2 = np.array([[[1,2,3],[4,5,6]] , [[7,8,9],[10,11,np.NaN]]])
print(array2)

mu.cprintTitle('4) 행렬의 차원과 모양')
print('차원', array2.ndim, '모양', array2.shape)

mu.cprintTitle('5) 행렬의 모양 변경')
na = np.array(range(10))
print('길이:', len(na))  # 10x1 array
nb = na.reshape(2, 5)
print('길이:', len(nb))  # 2x5 array

# 2. 행렬 데이터의 선택
mu.cprintTitle('2. 행렬 데이터의 선택')
array = np.array([[[1,2,3],[4,5,6]],[[7,8,9],[10,11,np.NaN]]])
print(array)

mu.cprintTitle('1) 데이터의 선택')
print('array[1] : \n', array[1])
print('array[1][0] : ', array[1][0])
print('array[1][0][2] : ', array[1][0][2])

mu.cprintTitle('2) [] 생략가능')
print('array[1,0,2] : ', array[1,0,2])

mu.cprintTitle('3) 범위로 선택 가능')
print('array[1:, :, :2] :\n', array[1:, :, :2])
print('array[1:, :, 1:] :\n', array[1:, :, 1:])
print(array[1:, :, :1])

mu.cprintTitle('4) 데이터 수정')
ls = np.array(range(5), dtype='float')
ls[2] = 1.9
print(ls)

mu.cprintTitle('5) 브로드캐스팅 수정')
ls = np.array(range(5))
print('변경 전 ls : ', ls)
ls[3:] = 0
print('변경 후 ls : ', ls)

# 3. 행렬 데이터의 생성 2
mu.cprintTitle('3. 행렬 데이터의 생성 2')
print('1) zeros')
zero = np.zeros((2, 3))
print('np.zeros((2,3)) :')
print(zero)
print()
print('2) ones')
ones = np.ones((4, 3), dtype=int)
print('np.ones((4, 3), dtype=int) :')
print(ones)

"""
Q1.
5개의 1로 이루어진 1차원 행렬(벡터)을 만드시오.
[1, 1, 1, 1, 1]
"""
print('Q1')
q1 = np.ones((1,5), dtype=int)
print(q1[0])

q1 = np.ones(5, dtype=int)
print(q1)
"""
Q2.
10개의 1로 만들어진 정수 데이터 타입의 벡터에서 마지막 3개는 5로 바꾸시오.
[1, 1, 1, 1, 1, 1, 1, 5, 5, 5]
"""
print('Q2')
q2 = np.ones((1, 10), dtype=int)[0]
print(q2)
q2[7:] = 5
print(q2)

# 4. arange
print('4. arange')
ar1 = np.arange(10)
ar2 = np.arange(5, 10)
ar3 = np.arange(5, 10, 2)
print(type(ar1))
print(ar2)
print(ar3)
print(type(range(5)))

# 5. linspace, logspace
print()
print('5. linspace, logspace')
# 0 ~ 100까지를 5개로 분할
lin = np.linspace(0, 100, 5)
log = np.logspace(0, 2, 5)
print('linspace :', lin)
print('logspace :', log)

"""
Q3.
1에서 10까지의 홀수 데이터를 갖는 벡터를 만드시오.
[1, 3, 5, 7, 9]
"""
print()
print('Q3')
q3 = np.arange(1, 10, 2)
print(q3)
"""
Q4.
0부터 8까지의 값을 갖는 3x3 행렬을 만드시오.
"""
print('Q4')
q4 = np.arange(9)
q4 = q4.reshape(3, 3)
print(q4)

# 6. Numpy Random
print()
mu.cprintTitle('6. Numpy Random')
print('1) seed')
np.random.seed(1)
result1 = np.random.randint(low=10, high=100, size=10)
print(result1)
np.random.seed(1)
result2 = np.random.randint(low=10, high=100, size=10)
print(result2)
np.random.seed(283752)
result3 = np.random.randint(low=10, high=100, size=10)
print(result3)
np.random.seed(1)
result4 = np.random.randint(low=10, high=100, size=11)
print(result4)

print('2) rand')
rd = np.random.rand(10)
print(rd)

print('3) randn')
rd = np.random.randn(100)
print(min(rd), max(rd))
print(rd)

print()
print('4) randint')
rd = np.random.randint(5, 10, (2, 3))
print(rd)
rd = np.random.randint(5, size=(4, 3))
print(rd)

print()
print('5) shuffle')
rd = np.random.randint(1, 10, size=(3, 4))
print(rd)
np.random.shuffle(rd)
print('after shuffle')
print(rd)

# 모든 차원의 데이터를 변경할 때는 1차원으로 변경 후 shuffle, 다시 원래 차원으로 복귀
print('rd.shape :', rd.shape)
print('rd.size :', rd.size)

# 1차원으로 변경
m1 = rd.reshape(rd.size)
print('after 1 dim :', m1)
# shuffle
np.random.shuffle(m1)
print('after shuffle :', m1)
# 원래 차원으로 복귀
all_shuffle = m1.reshape(rd.shape)
print('all_shuffle :')
print(all_shuffle)

print()
print('6) choice')
np.random.seed(273872)
# choice(모집단, 개수, p=확률)
c = np.random.choice(range(1,6), 10, p=[0.1, 0.2, 0.5, 0.2, 0])
print(c)
