"""
    My First Python Program
    Version : 1.0
    Created : 2021.11.09
    Updated : 2021.11.09
"""
from colors import *

# print('jwlee')
# print('***********')

print('#' * 40)
print('My First Program')
print('#' * 40)

my_name = 'jwlee'
your_name = "noname"
my_name2 = 'jw "Dangerous" lee'  # 작은 따옴표로 시작했기 때문에 "가 일반 문자로 인식
my_name3 = "jw 'Sleepy' lee"     # 큰 따옴표로 시작했기 때문에 '가 일반 문자로 인식
statement1 = 'this is \n very big' # \n : 새로운 줄
statement2 = 'this is \t very big' # \t : 탭

print(my_name, end='') # print 마지막에 출력할 문자, default는 \n
print(my_name, your_name, my_name2, my_name3) # ,로 구분하면 공백을 두고 출력
print(my_name, your_name, RED + my_name2 + END, GREEN + my_name3 + END) # color
print(statement1)
print(statement2)
#print(my_name * 50)

