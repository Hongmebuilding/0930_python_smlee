"""
    Control Statement
    Version : 1.0
    Created : 2021.11.18
    Updated : 2021.11.18
    Author  : J.W.Lee
"""

# 1. while문
print('#' * 40)
print('while statement')
print('#' * 40)

print('노가다')
print('1번 출력')
print('2번 출력')
print('3번 출력')
print('4번 출력')
print('5번 출력')
print('6번 출력')
print('7번 출력')
print('8번 출력')
print('9번 출력')
print('10번 출력')
print('\n')  # 두 줄 띄우기

print('자동화')
i = 1
while i < 11:
    print('{}번 출력'.format(i))
    i = i + 1

# while True:
#     print('막을 수 없어')

print('#' * 40)
print('infinite loop')
print('#' * 40)

# while True:
#     num = input('1에서부터 10까지의 숫자 중 하나를 입력해주세요 : ')
#     if num.isdecimal() == True:
#         # 숫자가 맞으면 도는 로직
#         if int(num) >= 1 and int(num) <= 10:
#             print('입력하신 숫자는 {}입니다.'.format(num))
#             break
#         else:
#             print('숫자는 맞으나 범위가 잘못되었습니다')
#     else:
#         print('{}은 숫자 아니잖아 확'.format(num))

print('#' * 40)
print('for statement')
print('#' * 40)

print('### 문자열')
for str in '문자열집합':
    print(str)

print('### list')
for lst in ['첫번째','두번째','세번째']:
    print(lst)

print('### tuple')
vivaldi_season4 = ('Spring','Summer','Fall','Winter')
print(type(vivaldi_season4))
for season in vivaldi_season4:
    print(season)

print('### set')
vivaldi_season4 = {'Spring','Summer','Fall','Winter'}
print(type(vivaldi_season4))
for season in vivaldi_season4:
    print(season)

print('### range')
for i in range(5): # 0,1,2,3,4
    print(i)

for i in range(1,10,1): # 1 ~ 9, 10은 포함되지 않음을 기억
    print(i)

print('### dict')
person = {'name':'jwlee', 'age':100}
for item in person:
    print(item)     # key값이 나옴
    print(person[item]) # value를 얻는 첫 번째 방법
    print(person.get(item)) # value를 얻는 두 번째 방법





