"""
    Day3 5 min Challenge
    Version : 1.0
    Created : 2021.11.16
    Updated : 2021.11.16
"""
RED = '\033[91m'
GREEN = '\033[92m'
END = '\033[0m'

# 1.사용자로부터 숫자 입력을 하나 받는다.
num = float(input(RED + '숫자를 입력해라 : ' + END))

# 2.입력한 숫자가 양수인지 0인지 음수인지를 출력한다.
if num > 0:
    print(GREEN + '양수네' + END)
elif num == 0:
    print('0인지 모르냐')
else:
    print(RED + '음수입니다'+ END)
