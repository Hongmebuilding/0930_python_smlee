"""
    Day2 5 min Challenge
    Version : 1.0
    Created : 2021.11.11
    Updated : 2021.11.11
"""
# 1. 사용자로부터 파이썬 점수, 자바 점수, C 점수를 입력받는다.
p_score = input('파이썬 점수는?')
j_score = input('자바 점수는?')
c_score = input('C 점수는?')

# 여러 개를 입력받는 방법
p, j, c = input('파이썬, 자바, C점수를 공백으로 구분하여 각각 입력하시오 : ').split()
print(p,j,c)

# 2. 입력한 값들의 합계와 평균을 구한다.
all_sum = float(p_score) + float(j_score) + float(c_score)
all_avg = all_sum / 3

# 3. 결과를 출력한다.
print('총 점수합계는 ' + str(all_sum) + '점')
print('총 점수평균은 ' + str(all_avg) + '점')

