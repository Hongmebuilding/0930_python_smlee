"""
    Built-in Functions
    Version : 1.0
    Created : 2021.11.30
    Updated : 2021.11.30
    Author  : J.W.Lee
"""

from myutils import *

cprintTitle("11.range()")
printExp("range(10)")
print(range(10))
print(type(range(10)))

a = list(range(10))
print(a)
a = list(range(1, 100, 2))  # step = 2
print(a)
a = list(range(10, 0, -1))  # 10, 9, ... 1
print(a)
a = list(range(0, 15, -5))
print(a)

cprintTitle("12.sorted()")
student = ['A학생11111', 'a학생', 'B학생', '12345']
# ASCII : 0x30(16*3 + 0 = 48)부터가 숫자, 0x41부터가 A, 0x61부터가 a
student_a = sorted(student, reverse=False)
print(student_a)
student_a = sorted(student, reverse=True)
print(student_a)

cprintTitle("13.enumerate(), zip()")
print(enumerate(student))
student_e = list(enumerate(student))
print(student_e)

for s in enumerate(student):
    print(s[0], s[1])

student_i = ['30444', '30122', '20312', '11111']
print(zip(student, student_i))
print(list(zip(student, student_i)))
for s in zip(student, student_i):
    print(s[0], s[1])

cprintTitle("Method of List")
list_a = [1, 2, 3]
print(list_a)
# list[3] = 4 # 불가 index out of range
list_a.append(4)
print(list_a)
list_a.append("abcde")
print(list_a)
print(list_a[0] * list_a[1])
list_a.insert(2, 655555)
print(list_a)
list_b = [4, 5, 6, 7, 8]
list_a.extend(list_b)
print(list_a)
tuple_a = (5434, 2323)
list_a.extend(tuple_a)
print(list_a)
set_a = {1232, 123123, 3242}
list_a.extend(set_a)
print(list_a)

b = list_a.pop()
c = list_a.pop(0)
print(b, c)
print(list_a)

e = list_a.remove('abcde')
print(e)
print(list_a)
f = list_a.remove(4)
print(list_a)

# g = list_a.index(4, 4)  # 못찾으면 오류
g = list_a.index(4, 1)  # 몇 번부터 찾든 index는 list의 시작부터의 값
print(g)

list_a.clear()
print(list_a)




