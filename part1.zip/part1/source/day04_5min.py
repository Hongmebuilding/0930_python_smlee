"""
    Day4 5 min Challenge
    Version : 1.0
    Created : 2021.11.18
    Updated : 2021.11.18
"""
"""
    1. '이름을 입력하세요 :'를 출력하고 입력을 받는다.
    2. '최대 숫자를 입력하세요 :'를 출력하고 입력을 받는다.
    3. 1부터 입력한 최대 숫자 사이의 임의의 수를 만든다.
    4. 숫자 입력을 받아 임의의 수와 같은지 맞추는 게임을 만든다.
       정답은 몇일까요? 를 출력하고 입력을 받는다.
       임의의 수와 입력한 수가 동일할 때까지 계속한다.
       5번까지 못 맞추면 종료한다.
    5. 한 번에 정답을 맞추면 '***님 대단하십니다'
       세 번 이내에 정답을 맞추면 '***님 우수한 성적이십니다'
       다섯 번 이내에 맞추면 '***님 좀 심하십니다'
       다섯 번까지 못 맞추면 '정답은 *입니다. *님 사람 맞아요?'
"""
# 1
nam = input('이름을 입력하세요 :')
# 2
# 2-1. 숫자 입력을 받아 변수에 저장한다.
num = input('최대 숫자를 입력하세요 :')
# 2-2. 숫자인지 파악하고 숫자가 아니면 계속 입력을 받는다.
# str.isdecimal()를 이용
while True:
    if num.isdigit() == True:
        break
    num = input('최대 숫자를 입력하세요 :')

# 3. 임의의 수를 만든다.
import random
rand_num = random.randint(1,int(num))
# print(rand_num)

# 4. 정답은 몇일까요?로 다섯 번 맞추는 반복문을 실행한다.
count = 1
iscorrect = False

while True:
    # 정답을 입력받고 비교하는 로직
    ans = input('정답은 몇일까요? ')
    if ans.isdigit():
        if rand_num == int(ans):  # 정답
            print('정답입니다')
            iscorrect = True
            break
        else:
            print('오답입니다')
    if count == 5:
        break
    count = count + 1

# print('count =', count)
# print('iscorrect =', iscorrect)

# 5. 결과를 출력한다.
if iscorrect:
    if count == 1:
        print('{}님 대단하십니다'.format(nam))
    elif count <= 3:
        print('{}님 우수한 성적이십니다'.format(nam))
    else:
        print('{}님 좀 심하시네요')
else:
    print('정답은 {}입니다. {}님 사람 맞아요?'.format(rand_num, nam))

