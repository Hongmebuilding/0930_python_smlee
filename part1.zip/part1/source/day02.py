"""
    Print, Input, Operator
    Version : 1.0
    Created : 2021.11.11
    Updated : 2021.11.11
"""

RED = '\033[91m'
GREEN = '\033[92m'
END = '\033[0m'

print(RED + '1.Print Test' + END)
# 1. 화면에 Hello + 본인이름 을 출력하시오.
print('Hello JWLEE')

# 2. Mary's cosmetics
print("Mary's cosmetic")
print('Mary\'s cosmetic')

# 3. 신씨가 "도둑이야"라고 소리쳤다.
print('신씨가 "도둑이야"라고 소리쳤다.')
print('신씨가 \"도둑이야\"라고 소리쳤다.')

# 4. "C:\Windows"
print('\"C:\\Windows\"')

# 5. a = 'first', b = 'second'일 때 first second를 출력
a = 'first'
b = 'second'
print(a, b)

# 6. naver/kakao/meta
print('naver/kakao/meta')

print(GREEN + '2.Input Test' + END)
# a = input()
# print(a)
# b = input('값을 입력하세요 : ')
# print(b)
# c = float(a) + int(b)  # cf) (int)b
# print('a와 b의 합은', c, '입니다')

print()
print(GREEN + '3.Operator' + END)
print('(1)산술연산자')
a = 'My Name'
b = 'is None'
print(a + ' ' + b)
c = 'I\'ll be '
d = 100
# print('I\'ll be + 100 :', c + d) # 문자열과 숫자의 덧셈은 불가
print('I\'ll be + 100 :', c + str(d))

print('10 - 10.9 =', 10-10.9)
# print('My name' - 'My') # 문자열 - 문자열은 불가

print('안녕' * 5)
# print('ddd'/10) # 문자열은 나눗셈 불가능
# print(10/0) # 0으로 나눗셈 불가능

print('10 // 3 =', 10//3)
print('10 % 3 =', 10%3)
print('5 ** 3 =', 5**3)

print()
print('(2)관계연산자')
a = 30
b = 20
c = a > b
print(c)
print('c의 자료형은?', type(c))

print('10 > 10 :', 10 > 10)
print('10 >= 10 :', 10 >= 10)
print('10 < 20 :', 10 < 20)
print('10 == 20 :', 10 == 20)
print('10 != 20 :', 10 != 20)




