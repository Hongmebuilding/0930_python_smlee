"""
    Day9 5 minute Challenge
    Version : 1.0
    Created : 2021.12.02
    Updated : 2021.12.02
    Author  : J.W.Lee
"""
"""
    1. 문자열을 2개 입력받는다.
    2. 공통으로 존재하는 문자를 찾는다.
    3. "첫 번째 문자열의 길이 : *, 두 번째 문자열의 길이 : * "
       "공통으로 존재하는 문자 개수 : *" 를 출력한다.
    4. 첫 번째 문자열과 두 번째 문자열을 출력하되
       공통된 문자만 색을 입혀 출력한다.
"""
from myutils import *

str1 = input('첫 번째 문자열을 입력하세요 : ')
str2 = input('두 번째 문자열을 입력하세요 : ')

str1_spl = []
str2_spl = []

for c in str1:
    str1_spl.append(c)
for c in str2:
    str2_spl.append(c)

print(str1_spl, str2_spl)

str1_set = set(str1_spl)
str2_set = set(str2_spl)
res_set = str1_set.intersection(str2_set)
res_list = list(res_set)
if ' ' in res_list:
    res_list.remove(' ')

#  print(res_set)

print('첫 번째 문자열의 길이 : {}, 두 번째 문자열의 길이 : {}'.format(len(str1), len(str2)))
print('공통으로 존재하는 문자 개수 : {}'.format(len(res_list)))

for c in str1:
    if c in res_list:
        print(RED + c + END, end='')
    else:
        print(c, end='')
print()
for c in str2:
    if c in res_list:
        print(GREEN + c + END, end='')
    else:
        print(c, end='')
