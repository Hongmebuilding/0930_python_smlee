"""
    Method
    Version : 1.0
    Created : 2021.12.02
    Updated : 2021.12.02
    Author  : J.W.Lee
"""
from myutils import *

tuple_a = (1,2)
# tuple_a.pop()  # tuple은 append, insert, extend, pop 모두 안됨

cprintTitle("Set Method")
a = {1, 2, 3, 4, 5}
b = {3, 4, 5, 6, 7}
c = a.intersection(b)
d = a.union(b)
e = a.difference(b)
print(c, d, e)

cprintTitle("Dictionary Method")
dic = {
    1:'one',
    'subject':['science', 'korean'],
    '숫자':1234
}
print(dic)

# dic[1:3]  # dictionary는 순서가 존재하지 않음
print(dic.keys())
print(type(dic.keys()))  # class는 dict_keys
print(dic.values())
print(dic.items())  # key와 value를 tuple로 반환

print(dic.get(1))
print(dic[1])

print(dic.get(8))  # 없는 key로 조회해도 None 반환
# print(dic[8])  # 없는 key로 조회하면 오류
print(dic.get(8, "그런값없지롱"))

person = {'name':'Jmaes', 'age':53}

# person에서 꺼내오면 key만 꺼내옴
for item in person:
    print(item, end="")
    print(person.get(item))

for item in person.items():
    print('{}:{}'.format(item[0], item[1]))

cprintTitle("String")
a = 'abcdefg'
print(a)
print(a[0], a[1], a[2], a[3], a[5])
print(a[1:3])
print(a[3:])
print(a[3::2])

cprintTitle("Array Copy")
a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
b = a[1:8]
print("List :", b)
b = a[1:8:2]
print("List :", b)
c = a[1:]
print("List :", c)

d = (1, 2, 3, 4, 5)
e = d[2:]
print("Tuple :", e)

f = {1, 2, 3, 4, 5}
g = f  # Set은 전체 복사만 가능
print("Set :", g)

cprintTitle("User Function")
printMessage1()
printMessage2('abcde')
printMessage3('33333')
printMessage3()
printMessage4('James', 3)
printMessage4(i=3)
result = getRandomDice(100)
a, b, c = multiReturn(1, 2, 3)  # 받을 변수 개수가 정확해야 한다.
print(a, b, c)
result = addAll(1,2,3,4,5,6,7,8,9,10,10000)
print(result)

a, b, c = checkPhoneNumber('011-3345-4223')
print(a, b, c)



