"""
    Control Statement
    Version : 1.0
    Created : 2021.11.19
    Updated : 2021.11.19
    Author  : J.W.Lee
"""
# 1. while
i = 1
while i < 10:
    print(i)
    i = i + 1

# 2. for
for i in range(1,10):
    print(i)
    i = 9   # for 문장에서 1..9가 순서대로 돌아가며 실행되도록 정해졌기 때문에 중간에 바꿔도 원래로 돌아간다.
    print(i)

# 3. break
print('#' * 40)
print('break')
print('#' * 40)

n = 1
while True:
    if n == 10:
        break
    print(n)
    n += 1

# 4. continue
print('#' * 40)
print('continue : 1부터 9중에 3의 배수만 빼고 출력')
print('#' * 40)

n = 1
while True:
    if n == 10:
        break
    elif n % 3 == 0:
        n += 1
        continue
    print(n)
    n += 1

print('#' * 40)
print('list')
print('#' * 40)

list_simple = [1, 2, 3]
list_bokjap = [[1, 2, 3], [4, 5, 6]]
list_thebokjap = [[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]]

print(list_simple)
print(list_simple[0])  # 첫 번째 것
print(list_bokjap[1])  # 두 번째 것
print(list_bokjap[1][1])  # 두 번째 것 중 두 번째
print(list_thebokjap)
print(list_thebokjap[0][1][2])  # 음..............

print(list_simple[1:3])

# module
# import myutils as mu
from myutils import *

print('이건 색이 없던데 ' + YELLOW + '노란색' + END + ' 나오나요')

# color
# 1. 기본 8색
print('#' * 40)
print('8 color')

str = ['', '', '', '']
str[0] = YELLOW + '노란색' + END
str[1] = CYAN + '하늘색' + END
str[2] = RED_BG + '빨간바탕' + END
str[3] = BLACK + GREEN_BG + '녹색바탕에 검정색' + END

for s in str:
    print(s)

# 2. 256 color
print('#' * 40)
print('256 color')

str = '\033[38;5;38m' + '딥스카이블루' + END
print(str)

# 밝은 배경 8색 display
color8_str = ''
for i in range(100,108):
    color8_str = color8_str + '\033[{}m'.format(i) + '   ' + END

print(color8_str)

# 256색 display
color256_str = ''
for i in range(0,256):
    color256_str += '\033[48;5;{}m'.format(i) + ' ' + END
print(color256_str)

# True Color
print('#' * 40)
print('True color')

str_list = ['', '', '', '']

for i in range(127,256):
    str_list[0] += '\033[48;2;{};0;0m'.format(i) + ' '
    str_list[1] += '\033[48;2;0;{};0m'.format(i) + ' '
    str_list[2] += '\033[48;2;0;0;{}m'.format(i) + ' '
    str_list[3] += '\033[48;2;{};{};{}m'.format(i, i, i) + ' '

for i in range(0,4):
    str_list[i] += END
    print(str_list[i])







