"""
    Built-in Functions
    Version : 1.0
    Created : 2021.11.25
    Updated : 2021.11.25
    Author  : J.W.Lee
"""

import myutils as mu

print('#' * 40)
print('Built-in Functions')

mu.cprintTitle('Built-in Functions')

mu.cprintTitle('1. eval()')
print('eval("1+1") => {}'.format(eval('1+1')))
mu.printExp('200+500')

mu.cprintTitle('2. format()')
mu.printExp('format(34567, ",")')
mu.printExp('format(34567, "_")')

mu.printExp('format("꽥꽥꽥꽥꽥","비<20")')
mu.printExp('format(1234, "0>10")')
mu.printExp('format(1234, "0>+10")')
mu.printExp('format(1234, "<10")')

mu.cprintTitle('3. str(), float(), int()')
print("str() : " + str(47) + "명이 출석 중")
print("10을 float를 씌우면 " + str(float(10)))
print("10.9를 int를 씌우면 " + str(int(10.9)))

mu.cprintTitle('4. divmod()')
mu.printExp('divmod(10, 3)')
a = divmod(10, 3)
print(a)
print(a[0])
print(a[1])
# a[1] = 5
# print(a[1])

b = [1, 2, 2]
c = set(b); print(c)
d = list(c); print(d)
e = tuple(b); print(e)
f = list(e); print(f)

mu.cprintTitle('5. min(), max()')
c = [1, 2, 3, 4, 5]
print(min(c))
mu.printExp('min([1,2,3,4,5])')
print(min(["1", "2", "3"]))
print(min(c) == min(["1", "2", "3"]))
print(type(min(c)), type(min(["1", "2", "3"])))
# mu.printExp('min([1,2,"3",4,5])')
print(max(1, 2, 3))

mu.cprintTitle('6. abs(), pow(), sum()')
mu.printExp('abs(-50.5)')
mu.printExp('pow(10, 3)')
mu.printExp('pow(10, -1)')
mu.printExp('pow(3, 1.5)')
# mu.printExp('sum(10)')
# mu.printExp('sum(10, 20)')
mu.printExp('sum([100,200,300])')
mu.printExp('sum([100])')
mu.printExp('sum([100,200,300], 2)')
mu.printExp('sum([100,200,300], start=2)')
g = [[10000, 200, 300], [10000, 500, 60000]]
# sum(g)
print(max(g))
h = ['a', 'b', 'c']
# print(sum(h))
i = ['a']
# print(sum(i))

mu.cprintTitle('7. round()')
mu.printExp('round(234.2)')
mu.printExp('round(234.2, -3)')
mu.printExp('round(2.675, 1)')
mu.printExp('round(2.975, 2)')
mu.printExp('round(2.685, 2)')
mu.printExp('round(2.6751, 2)')
mu.printExp('round(2.6775, 3)')
mu.printExp('round(52, -1)')
mu.printExp('round(52, -2)')

mu.cprintTitle('8. print()')
mu.printExp('print("string1","string2")')
print('string3', 10)  # 인자(argument) 타입이 달라도 수행됨
print('010', '1234', '5678', sep='-', end='|')
print('010', 1234, '5678', sep='')

mu.cprintTitle('9. input()')
#input_str = input('아무거나 쳐봐 : ')
#a, b, c, d = input_str.split(' ')
#print(a, b, c, d)

mu.cprintTitle('10. len()')
mu.printExp('len("abcde")')
student = ['A1', 'B2', 'Z3']
print(len(student))
print(len(student[0]))
print(len('1234'))











