"""
    String, Variables, File
    Version : 1.0
    Created : 2021.12.03
    Updated : 2021.12.03
    Author  : J.W.Lee
"""
from myutils import *

cprintTitle('String Method')
s1 = 'my name is john'
print(s1.find('name'))  # 존재하면 인덱스 번호, 미존재 시 -1
print('name' in s1)  # name이 s1에 있는지 없는지를 bool 타입으로 반환
print('Name'.lower() in s1.lower())  # 대소문자 관계없이 찾고 싶을 때

s2 = s1.title()  # 각 단어의 첫 글자를 대문자로
print(s2)

s3 = '      I am a programmer@@@@@@@@@@1'
s4 = s3.lstrip(' ').rstrip('@1')
print(s4)

cprintTitle('Global Variables')
# 1단계
global_v = 10

def printVariables1():
    print('1단계 global_v :', global_v)

printVariables1()
print('1단계 global_v :', global_v)

# 2단계
def printVariables2():
    local_v = 20
    print('2단계 global_v :', global_v)
    print('2단계 local_v :', local_v)

printVariables2()
print('2단계 global_v :', global_v)
# print('2단계 local_v :', local_v)

# 3단계
def printVariables3():
    # print('3단계 global_v :', global_v)
    global_v = 30
    local_v = 30
    print('3단계 global_v :', global_v)
    print('3단계 local_v :', local_v)

printVariables3()
print('3단계 global_v :', global_v)
# print('3단계 local_v :', local_v)

# 4단계
def printVariables4(global_v):
    print('4단계 global_v :', global_v)
    global_v = 40
    local_v = 40
    print('4단계 global_v :', global_v)
    print('4단계 local_v :', local_v)

printVariables4('abcd')
print('4단계 global_v :', global_v)

# 5단계
def printVariables5():
    local_v = 50
    return local_v

global_v = printVariables5()
print('5단계 global_v :', global_v)

# 6단계
global_v1 = 61
global_v2 = 62

def printVariables6():
    global global_v1
    global_v1 = 601
    globals()['global_v2'] = 602
    global_v2 = 700

printVariables6()
print('6단계 global_v1 :', global_v1)
print('6단계 global_v2 :', global_v2)

# 7단계
if global_v1 == 601:
    local_new = 300

print('7단계 local_new :', local_new)

i = 9278232
for i in range(5):
    print(i)

print('8단계 local_new1 :', i)

cprintTitle('random module')
import random
a_list = ['a', 'b', 'c']
a_tuple = ('A', 'B', 'C')
a_set = {'1', '2', '3'}
print('random.choice :', random.choice(a_list), random.choice(a_tuple))
# print('random.choice :', random.choice(a_set))  # set은 순서가 없기 때문에 random 수행 안됨
print('random.sample :', random.sample(a_list, 2), random.sample(a_tuple, 2))
a_list2 = random.sample(a_list, len(a_list))  # Random으로 순서를 재배열할 때 사용하는 Trick
print(a_list2)

cprintTitle('math module')
import math
print('math.pi :', math.pi)
print('floor(-1.9), trunc(-1.9) :', math.floor(-1.9), math.trunc(-1.9))

cprintTitle('time module')
import time
t1 = time.time()
t2 = time.ctime(t1)
t3 = time.strftime('%Y/%m/%d %H:%M:%S')
print('time.time() :', t1)
print('time.ctime() :', t2)
print('time.strftime() :', t3)

cprintTitle('file')
s1 = 'We are studying Python'
s2 = '우리는 파이썬을 공부중입니다'

f = open('sample.txt', 'wt')
f.write(s1)
f.write(s2)
f.close()

f = open('sample5.txt', 'rt', encoding='utf-8')  # default는 window에 맞게 cp949
while True:
    readstr = f.readline()
    if readstr == '':
        break
    print(readstr, end='')