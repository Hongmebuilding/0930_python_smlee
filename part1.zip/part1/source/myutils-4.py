import random

BLACK = '\033[90m'
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'

RED_BG = '\033[101m'
GREEN_BG = '\033[102m'

END = '\033[0m'

import random as rd

def printExp(exp):
    print(exp + " => {}".format(eval(exp)))

def cprintTitle(str):
    col = rd.randint(0, 256)
    print('\033[38;5;{}m'.format(col) + '#' * 40)
    print(str + END)

def printMessage1():
    print('**********')

def printMessage2(message):
    print(message)

def printMessage3(message='입력을 하지 않으셨네요'):
    print(message)

def printMessage4(message='없어', i=5):
    for j in range(i):
        print(message)

def getRandomDice(i=6):
    r = random.randint(1, i)
    print('당신의 주사위는 ', r)
    return r

def multiReturn(i, j, k):
    return i * 100, j * 200, k * 300

# 숫자 입력을 받아 모두 더한 결과를 돌려주는 함수
def addAll(*i):
    res = 0
    for j in i:
        res = res + j
    return res

"""
    1. str이 숫자와 '-'로만 구성이 되어 있는지 check
    2. 숫자가 10자리 또는 11자리인지 check
    3. 정상이면 10자리이면 XXX, XXX, XXXX return
               11자리이면 XXX, XXXX, XXXX return
    4. 비정상이면 999, 9999, 9999 return
"""
def checkPhoneNumber(str):
    ndigit = 0
    nstring = ''

    # 1. 숫자와 '-'로만 구성이 되어 있는지 check
    for c in str:
        if c in '0123456789-':
            if c == '-':
                ndigit = ndigit + 0
            else:
                ndigit = ndigit + 1
                nstring = nstring + c
        else:
            return '999', '9999', '9999'

    # 2. 숫자가 10자리인지 11자리인지 check
    if ndigit == 10:
        return nstring[0:3], nstring[3:6], nstring[6:]
    elif ndigit == 11:
        return nstring[0:3], nstring[3:7], nstring[7:]
    else:
        return '999', '9999', '9999'