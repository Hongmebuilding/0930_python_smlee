"""
    Operator
    Version : 1.0
    Created : 2021.11.16
    Updated : 2021.11.16
    Author  : J.W.Lee
"""

# 논리연산자
print('10 > 2 and 10 < 20 :', 10 > 2 and 10 < 20)
print('10 != 0 or 10 >= 100 :', 10 != 0 or 10 >= 100)
print('not 10 > 3 :', not 10 > 3)

# str.format
print('{}은 또 하나의 {}함수 {}입니다.'.format('이것', 'print', '사용법'))
print('숫자도 되는지 해보죠 {}'.format(10))
print('되네요 괄호보다 입력이 더 많을 경우는 {}'.format('되네', '궁금하네'))  # 괄호보다 입력이 더 많을 때는 OK
# print('괄호보다 입력이 더 적을 때는 {} {}'.format(10)) # 괄호가 입력보다 많을 때는 오류

print('#'*40)
print('이름:{name}\n주소:{addr}'.format(name='jwlee', addr='미입력'))
print('#'*40)
print('이름:{1}\n주소:{0}'.format('jwlee', '미입력'))
print('#'*40)

# if statement
print('#' * 40)
print('if statement')
print('#' * 40)

print('*** a = 1 ***')
a = 1
if a > 0:
    print('a는 양수')

if a == 1:
    print('a는 1임')

if not a != 1:
    print('a는 1이 아닌게 아님')

a = -100
if a > 0:
    print('a는 양수2')
    # print('a는 양수3') # 오류 : 파이썬은 들여쓰기(indent)가 매우 중요함
  # print('a는 양수4') # 윗 줄보다 들여쓰기 레벨이 높아도 안됨
print('a는 양수5')

# if a < 0: print('a는 양수6') # if문 줄에 실행문을 넣으면 아래는 들여쓰기를 맞춰도 오류
#           print('a는 양수7')

if a < 0: print('a는 양수8'); print('a는 양수9')

# if a = 2:         # 파이썬은 할당연산자를 조건문에 넣을 수 없음
#    print('a는 2')

# if-else statement
print('#' * 40)
print('if-else statement')
print('#' * 40)

b = -1
if b > 0:
    print('b는 양수')
else:
    print('b는 양수 아님')

if b > 0:
    print('b는 양수')
else:
     print('b는 양수 아님2')
     print('b는 양수 아님3')

# if-elif statement
print('#' * 40)
print('if-elif statement')
print('#' * 40)

c = 0
if c > 0:
    print('c는 양수')
elif c == 0:
    print('c는 0')

d = 60
if d > 50:
    print('d는 큰 양수')
elif d > 0:
    print('d는 그냥 양수')

# if-elif-else statement
print('#' * 40)
print('if-elif-else statement')
print('#' * 40)

e = -30
if e > 0:
    print('e는 양수')
elif e == 0:
    print('e는 0')
else:
    print('e는 음수')





